public class StringConcatenation {
    public static void main (String []args){
        String str ="";
        for(int x=0; x<100001; x++){
            System.out.print(str.concat("x"));

        }
    }
}
