import java.util.LinkedList;

public class JavaLinkedList {
    public static void main(String[] args) {
        LinkedList<String> cars = new LinkedList<String>();

        cars.add("Toyota");
        cars.add("BMW");
        cars.add("Mazda");
        cars.add("Ford");

        System.out.println(cars);
        
    }
    
}
