
public class Counter {
    
    public int value ;


    public Counter(){
        value = 3;

    }
    public void increment(){
        value++;
    }
    public void decrement(){
        value--;
    }

}

